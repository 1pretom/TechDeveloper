package com.dh.primeiraAulaSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimeiraAulaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimeiraAulaSpringApplication.class, args);
	}

}
