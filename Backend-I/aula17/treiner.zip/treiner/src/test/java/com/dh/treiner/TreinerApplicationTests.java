package com.dh.treiner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TreinerApplicationTests {

	@Test
	void contextLoads() {
	}

}
